
var app = angular.module('myApp', []);

        app.controller('MainCtrl', function ($scope) {
            $scope.windows = { top: true, left:false, center:true, right: true};
            $scope.toggleall = function(state){
              $scope.windows.top = state;
              $scope.windows.left = state;
              $scope.windows.center = state;
              $scope.windows.right = state;
            }
        });
        
        
app.directive('toggler', function() { 
    var tpl ='<button ng-click="toggle()"  ng-transclude></button>';
    return {
        restrict: "A",
        template: tpl,
        transclude: true,
        replace: true,
        scope: {
            isVisible: '=toggler'   
        },
        controller: function ($scope) {
          
            $scope.toggle = function() {
                 $scope.isVisible = !$scope.isVisible;   
            }
        }
    }
});

app.directive('viewpanel', function() { 
    return {
        restrict: "A",
        scope: {
            isVisible: '=viewpanel'   
        },
        link: function (scope, el, attrs) {
            scope.$watch('isVisible', function (value, oldvalue)  {
               if (value) {
                 el.removeClass('hidden');
               } else {
                 el.addClass('hidden')
               }
            });
        }
    }
});
