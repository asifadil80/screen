# Angularjs Control screen sections visibility via the app model

This sample shows how to keep a top level model that states what blocks/ panels to display on the screen.

There are 2 different samples:
1. Using directives for each panel 
2. Using ng-show
 
### Run the code
http://plnkr.co/edit/d0Dq94?p=preview

### Check the code
https://gist.github.com/mritzco/9066154

### See this description in a fancy page

https://gist.io/9066154